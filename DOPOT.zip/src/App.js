import Home from "./views/Home";
import "bootstrap/dist/css/bootstrap.min.css";
function App() {
  return <Home />;
}

export default App;
